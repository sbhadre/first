export interface Employee {
  empid:number,
  name:string,
  age:number
}